@php
  setlocale(LC_ALL, 'IND');
@endphp
