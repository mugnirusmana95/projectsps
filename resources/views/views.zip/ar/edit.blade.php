@extends('index')

@section('title')
  Ubah Tagihan Beasiswa
@endsection

@section('content')
<section class="content-header">
  <h1>
    Ubah Tagihan Beasiswa
  </h1>
  <ol class="breadcrumb">
    <li><a href="/"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li><a href="/tagihan"> Tagihan Beasiswa</a></li>
    <li class="active"> Ubah Tagihan Beasiswa</li>
  </ol>
</section>

<section class="content">
  <div class="row">
    <div class="col-md-12">
      <div class="box box-primary">

        <form class="form-horizontal" action="/tagihan/ubah/simpan/{{$id}}" method="post">
          {{ csrf_field() }}
          <input type="hidden" name="_method" value="put">

          <div class="box-body">

            @if(Session::has('success'))
            <div class="alert alert-success alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <h4><i class="icon fa fa-check"></i> Success!</h4>
              {{Session::get('success')}}
            </div>
            @elseif(count($errors) > 0)
            <div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <h4><i class="icon fa fa-close"></i> Error!</h4>
              Data gagal disimpan.
            </div>
            @else
            <div class="alert alert-info alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <h4><i class="icon fa fa-info-circle"></i> Info!</h4>
              Field dengan field (<span class="req">*</span>) wajib diisi.
            </div>
            @endif

            <div class="form-group {{$errors->has('invoice') ? 'has-error' : ''}}">
              <label for="invoice" class="col-md-2 control-label">No Invoice <span class="req">*</span></label>
              <div class="col-md-8">
                <input type="text" class="form-control" id='invoice' placeholder="No Invoice" name="invoice" value="{{$ar->invoice}}" readonly>
                @if ($errors->has('invoice'))
                <span class="help-block">
                    {{$errors->first('invoice')}}
                </span>
                @endif
              </div>
            </div>

            <div class="form-group {{$errors->has('spk') ? 'has-error' : ''}}">
              <label for="spk" class="col-md-2 control-label">No SPK <span class="req">*</span></label>
              <div class="col-md-8">
                <select class="form-control select" name="spk" id="spk">
                  <option value=""></option>
                  @foreach ($scholarship as $key)
                  <option value="{{$key->id}}" @if($key->id == $ar->spk) selected @endif>{{$key->spk}} - {{$key->source}} - {{$key->year}}</option>
                  @endforeach
                </select>
                @if ($errors->has('spk'))
                <span class="help-block">
                    {{$errors->first('spk')}}
                </span>
                @endif
              </div>
            </div>

            <div class="form-group {{$errors->has('tgl') ? 'has-error' : ''}}">
              <label for="tgl" class="col-md-2 control-label">Tanggal Tagihan <span class="req">*</span></label>
              <div class="col-md-8">
                <input type="text" class="form-control" id='tgl' placeholder="yyyy-mm-dd" name="tgl" value="{{$ar->date}}">
                @if ($errors->has('tgl'))
                <span class="help-block">
                    {{$errors->first('tgl')}}
                </span>
                @endif
              </div>
            </div>

          </div>

          <div class="box-footer">
            <div class="form-group">
              <div class="col-md-2">
              </div>
              <div class="col-md-8">
                <button type="reset" class="btn btn-default">Reset</button>
                <button type="submit" class="btn btn-info">Simpan</button>
              </div>
            </div>
          </div>

        </form>
      </div>
    </div>
  </div>
</section>
@endsection
